# Remaining known limits

- Official v2 workbook alignment remains unverified because its actual file is not included. The provisional adapter is tested. Valentina owns that workbook and protocol.
- No genuine participant responses, independent human classifications, SUS results or eEVA execution are included.
- A partner dry run is still needed. Fixed BA order must be disclosed in the presentation.
- The shared researcher workspace has no password-based blinding. Use separate blind coding sheets and independent coding procedure.
- The mapper is a limited deterministic English heuristic; unsupported or conflicting text stays unresolved. No diagnostic validity is claimed.
- Frequency clarification/structured fallback are intentionally absent from deferred collection; their preserved legacy engine is tested separately.
- Only Edge was run here; file-URL storage policies may differ in other browsers. Keep verified private backups.
- Kappa is unweighted. No weighting definition or inferential testing is claimed.
- PR #1 is open and unmerged; main and the Desktop main checkout were preserved. No CI workflow/status checks are configured.
- Earlier reports, AB/BA instructions and the 28-column workbook are historical version 1.1.0 materials. Use current fallback instructions for version 1.2.1.
