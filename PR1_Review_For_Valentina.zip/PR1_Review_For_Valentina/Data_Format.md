# Export format and manual coding

All Test_Exports files are SYNTHETIC SOFTWARE TEST DATA — NOT ACTUAL PARTICIPANT RESULTS. They came from actual isolated browser interactions and downloads. The test automation’s manual codes are synthetic examples, without being work independently performed by Jai or Valentina.

## Raw CSV
There are 32 columns and one row per condition/item. A complete paired session has eight rows, B1–B4 then A1–A4. In the raw CSV `closed_category` is filled on A rows, while `original_response` on B rows holds the text. The initial and final automatic categories stay empty until the two-coder gate has been satisfied. `human_1` means Jai and `human_2` means Valentina. Blank means not entered; `unclear` means a coder could not assign a category. Zero means Never and must not be treated as missing.

`collection_mode=deferred` identifies the current fallback. `mapping_status=pending` means the mapper has not run; `mapped` means automatic success; `unclear` means unresolved; `unanswered` identifies missing text. In this fallback, clarification_count and structured fallback remain zero. The preserved interactive engine has separate behavior and tests.

`response_ms` is the item duration. `condition_ms` is copied to four item rows but must be counted once per session/condition. Start/end and date/time are UTC; elapsed durations use the browser monotonic clock. Recovery leaves unfinished condition duration unavailable and retains error notes.

## Nine-column provisional v2 adapter
Columns are Response ID, Participant, Question ID, Closed-ended answer, Free-text answer, Predicted category, Agree? (1 = yes), Completion time (s), Notes. Completion time is the B item time in seconds, not the whole session or eEVA conversation time. Pending/unclear/unanswered predictions and invalid paired references remain blank. Duplicate or missing A/B references are noted rather than silently choosing a row.

The official v2 workbook was not supplied with the PR, so direct workbook compatibility is not confirmed. Treat this as a tested provisional left-block adapter. Valentina should inspect the intended input columns and preserve official formula columns. Never paste 32 raw columns into the earlier 28-column replacement log or blindly overwrite the official workbook.

## Manual coding
Use the two blind sheets for independent coding: each omits closed-ended categories, predictions and the other coder. The combined sheet includes both coders, closed/automatic categories and agreement indicators for later comparison. Do not use the combined sheet as a blind coding form.

Manual_Coding_Template.csv is a header-only template. Its human columns are empty because no real data or coding was supplied. The researcher UI can record actual manual classifications. Alternatively, edit the combined CSV and run `node 02_Tests/manual_analysis.cjs comparison.csv result.json` in the reviewed repository. The script compares entered categories and never invents codes or invokes the mapper. It rejects invalid category values and excludes duplicate keys.

## CSV and Excel
Open CSVs normally through Excel File Open. UTF-8 BOM and quoted fields preserve commas, quotes, apostrophes, newlines and Unicode. Formula-leading text is protected with an apostrophe; use JSON for exact original text. Actual browser-suggested filenames, saved names, data-row counts and headers are in the verification JSON files.
